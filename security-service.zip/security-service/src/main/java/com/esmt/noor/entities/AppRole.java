package com.esmt.noor.entities;

public enum AppRole {
    CLIENT,
    ADMIN
}

